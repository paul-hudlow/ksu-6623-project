<?

class ulPhpDefaultSessionStorage
{
	public function gc()
	{
		// Do nothing, leave it completely up to PHP
		return true;
	}
}

?>