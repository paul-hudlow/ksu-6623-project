OpenID support requires external code.
To finish installation for OpenID, visit the LightOpenID website at http://code.google.com/p/lightopenid/,
download its distribution and place the openid.php in their archive into the ulogin/openid/lightopenid/ folder.