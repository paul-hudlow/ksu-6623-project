<html>
<h1>Page not found</h1>
<br/>
<?php echo $_SERVER["REQUEST_URI"]?>
</html>